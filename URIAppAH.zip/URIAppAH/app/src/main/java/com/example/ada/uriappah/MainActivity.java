//Inclass 15, Ada Ho, CIS494 4:30pm
package com.example.ada.uriappah;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button button;
    RadioButton rdoToast;
    RadioButton rdoActivity;
    Spinner spnSites;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        button = (Button) findViewById(R.id.btnOpen);
        rdoToast = (RadioButton) findViewById(R.id.rdoToast);
        rdoActivity = (RadioButton) findViewById(R.id.rdoActivity);
        spnSites = (Spinner) findViewById(R.id.spnSite);

        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

                String url;
                url = spnSites.getSelectedItem().toString();

                if(rdoToast.isChecked()){
                    Toast.makeText(v.getContext(),"You clicked Toast",Toast.LENGTH_SHORT).show();
                }
                else if(rdoActivity.isChecked()){
                    Intent intent = new Intent(v.getContext(),DetailActivity.class);
                    intent.putExtra("URL", url);

                    startActivity(intent);
                }
            }
        });
    }


}
