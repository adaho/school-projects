//Assignment 3, Ada Ho, CIS494 4:30pm
package com.example.ada.calculatorapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button buttonPlus;
    Button buttonMinus;
    Button buttonDivide;
    Button buttonMultiply;
    Button buttonCompute;
    Button buttonDecimal;
    Button buttonClear;
    TextView answerDisplay;
    double number1;
    double number2;
    String operatorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button0 = (Button) findViewById(R.id.btn0);
        button1 = (Button) findViewById(R.id.btn1);
        button2 = (Button) findViewById(R.id.btn2);
        button3 = (Button) findViewById(R.id.btn3);
        button4 = (Button) findViewById(R.id.btn4);
        button5 = (Button) findViewById(R.id.btn5);
        button6 = (Button) findViewById(R.id.btn6);
        button7 = (Button) findViewById(R.id.btn7);
        button8 = (Button) findViewById(R.id.btn8);
        button9 = (Button) findViewById(R.id.btn9);
        buttonPlus = (Button) findViewById(R.id.btnAdd);
        buttonMinus = (Button) findViewById(R.id.btnMinus);
        buttonMultiply = (Button) findViewById(R.id.btnMultiply);
        buttonDivide = (Button) findViewById(R.id.btnDivide);
        buttonCompute = (Button) findViewById(R.id.btnEqual);
        buttonDecimal = (Button) findViewById(R.id.btnDecimal);
        buttonClear = (Button) findViewById(R.id.btnClear);
        answerDisplay = (TextView) findViewById(R.id.txtResult);

        button0.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "0");
            }
        });

        button1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + "9");
            }
        });

        buttonDecimal.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                answerDisplay.setText(answerDisplay.getText() + ".");
            }
        });

        buttonPlus.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                operatorText = "+";
                number1 = Double.parseDouble(answerDisplay.getText().toString());
                answerDisplay.setText("");
            }
        });

        buttonMinus.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                operatorText = "-";
                number1 = Double.parseDouble(answerDisplay.getText().toString());
                answerDisplay.setText("");
            }
        });

        buttonMultiply.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                operatorText = "*";
                number1 = Double.parseDouble(answerDisplay.getText().toString());
                answerDisplay.setText("");
            }
        });

        buttonDivide.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                operatorText = "/";
                number1 = Double.parseDouble(answerDisplay.getText().toString());
                answerDisplay.setText("");
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                number1 = 0;
                number2 = 0;
                operatorText = "";
                answerDisplay.setText("0");
            }
        });

        buttonCompute.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                double total = 0.0;
                number2 = Double.parseDouble(answerDisplay.getText().toString());

                switch(operatorText){
                    case "+":
                        total = number1 + number2;
                        break;
                    case "-":
                        total = number1 - number2;
                        break;
                    case "*":
                        total = number1 * number2;
                        break;
                    case "/":
                        total = number1 / number2;
                        break;
                }

                answerDisplay.setText(Double.toString(total));
            }
        });
    }

}
